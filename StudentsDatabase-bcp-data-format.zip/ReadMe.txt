You can also import the data using plain old bcp commands, and this should work on any version of SQL Server.  To do this, you need to complete the following steps.

1) Log into your SQL Server and create a database named "Students".  You can actually call it anything you want, but you would have to modify some of the other commands below.

2) In the database you just created in management studio, open a new query window and paste in the file Students-Schema.sql that was included in this archive.  Click the execute button, and this will create all of the tables that you need.

3) At either a command prompt or powershell prompt, run all of the bcp commands that are in the file bcp-commands.txt.  If you want, rename this file as a bat file and run it (I purposely did not make it a bat file because I think everyone should look at something like this before they run it).

bcp is a SQL Server command line utility used to import and export data.  You may need to add it to your path.  It usually lives somewhere like ""C:\Program Files\Microsoft SQL Server\<<version>>\Tools\Binn\bcp".

The commands look like the following

    bcp students.dbo.Terms in Terms.dat -S localhost\sqlexpress -T  -n
	
	**students.dbo.Terms is the target table.
	**in specifies we are importing data into SQL Server
	**Terms.dat is the name of the data file
	**-S gives the location of the server.  If you are using SQL Express, don't forget the instance name
	**-T means use a trusted connection (use integrated Windows auth)
	**-n means the file is in SQL Server native type format.
	
	If you need to use a SQL Server account, then replace the "-T" with "-U <<username>>" and include the username you want to use.